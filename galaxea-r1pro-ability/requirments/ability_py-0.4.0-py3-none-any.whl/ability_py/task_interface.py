class TaskInterface:
    def execute(self, input_data: dict) -> dict:
        raise NotImplementedError
