import logging

# 获取 logger 实例
logger: logging.Logger = logging.getLogger("ability-py")
