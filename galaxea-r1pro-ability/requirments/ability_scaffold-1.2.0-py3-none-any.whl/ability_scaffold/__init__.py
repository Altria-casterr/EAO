"""AbilityFramework 能力工程脚手架 + 打包工具"""
__version__ = "1.2.0"
